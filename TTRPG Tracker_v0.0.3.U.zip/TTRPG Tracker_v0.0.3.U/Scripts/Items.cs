using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Items : MonoBehaviour
{
    //needed for getting data from master script
    GameObject Master;
    private MainMenu MasterScript;
    private string GameNum;
    private string ItemType;
    //Needed for displaying + creating the items
    public GameObject Item;
    public int distBetweenGameItems = 35;
    //Creation
    public GameObject CreateItemPop;
    public InputField CreateItemIn;
    //loading
    private int NumItems;
    //needed for UpdateTitle
    public GameObject Title;

    // Start is called before the first frame update
    void Start()
    {
        //Get the needed variables from the main script
        Master = GameObject.FindGameObjectWithTag("Master");
        MasterScript = Master.GetComponent<MainMenu>();
        GameNum = MasterScript.GameNumber;
        ItemType = MasterScript.ItemType;

        Item.SetActive(false);
        CreateItemPop.SetActive(false);
        UpdateTitle();
        loadItems();
    }

    public void UpdateTitle()
    {
        if (ItemType.Equals("I"))
        {
            Title.GetComponent<UnityEngine.UI.Text>().text = "Items";
        }
        else if (ItemType.Equals("S"))
        {
            Title.GetComponent<UnityEngine.UI.Text>().text = "Spells";
        }
        else if (ItemType.Equals("N"))
        {
            Title.GetComponent<UnityEngine.UI.Text>().text = "NPCs";
        }
        else
        {
            Title.GetComponent<UnityEngine.UI.Text>().text = "Locations";
        }
    }

    public void PopUpCreateItem()
    {
        if (CreateItemPop.activeSelf)
        {
            CreateItemPop.SetActive(false);
        }
        else
        {
            CreateItemIn.text = "";
            CreateItemPop.SetActive(true);
        }
    }

    public void loadItemDetails()
    {
        MasterScript.DetailsNum = GetDetailsNum();
        SceneManager.LoadScene(5);
    }

    private string GetDetailsNum()
    {
        GameObject buttonPressed = UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject;
        string name = buttonPressed.name + "D";
        return name;
    }


    public void CreateItem()
    {
        if (PlayerPrefs.HasKey(GameNum + ".N" + ItemType))
        {
            CopyGame(CreateItemIn.text, PlayerPrefs.GetInt(GameNum + ".N" + ItemType));
            PlayerPrefs.SetString(GameNum + "." + (PlayerPrefs.GetInt(GameNum + ".N" + ItemType)) + "." + ItemType, CreateItemIn.text);
            PlayerPrefs.SetInt(GameNum + ".N" + ItemType, (PlayerPrefs.GetInt(GameNum + ".N" + ItemType) + 1));
        }
        else
        {
            CopyGame(CreateItemIn.text, 0);
            PlayerPrefs.SetString(GameNum + "." + "0." + ItemType, CreateItemIn.text);
            PlayerPrefs.SetInt(GameNum + ".N" + ItemType, 1);
        }
        CreateItemPop.SetActive(false);
    }

    private void loadItems()
    {
        if (PlayerPrefs.HasKey(GameNum + ".0" + "." + ItemType))
        {
            NumItems = PlayerPrefs.GetInt(GameNum + ".N" + ItemType);
            for (int i=0; i<NumItems; i++)
            {
                CopyGame(PlayerPrefs.GetString(GameNum + "." + i + "." + ItemType), i);
            }
        }
    }

    public void back()
    {
        if (ItemType.Equals("N") || ItemType.Equals("L"))
        {
            SceneManager.LoadScene(1);
        }
        else
        {
            SceneManager.LoadScene(2);
        }
    }

    private void CopyGame(string name, int NumItems) //Make sure to properly set the Global GameNum variable before calling this method
    {
        //clone the object
        GameObject clone = Instantiate(Item);
        //set the display text of the cloned game object
        clone.transform.GetChild(0).GetComponent<UnityEngine.UI.Text>().text = name;
        //set the name of the game object
        clone.name = GameNum + "." + NumItems + "." + ItemType;
        //Set the parent of the cloned game
        clone.transform.SetParent(Item.transform.parent);
        //Put the clone at its proper location
        float posX = Item.transform.position.x;
        float posY = Item.transform.position.y - distBetweenGameItems * NumItems;
        clone.transform.position = new Vector3(posX, posY);
        //make the clone visable
        clone.SetActive(true);
    }
}
