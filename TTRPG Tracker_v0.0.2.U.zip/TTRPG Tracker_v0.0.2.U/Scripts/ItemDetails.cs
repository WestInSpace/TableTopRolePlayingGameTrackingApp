using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class ItemDetails : MonoBehaviour
{
    //needed to get values from master script
    GameObject Master;
    private MainMenu MasterScript;
    private string DetailsNum;
    //needed for loading a storing detials
    public InputField Details;
    //needed to update title
    public GameObject Title;

    // Start is called before the first frame update
    void Start()
    {
        //Get the needed variables from the main script
        Master = GameObject.FindGameObjectWithTag("Master");
        MasterScript = Master.GetComponent<MainMenu>();
        DetailsNum = MasterScript.DetailsNum;
        UpdateTitle();
        loadDetials();
    }

    private void UpdateTitle()
    {
        Title.transform.GetComponent<UnityEngine.UI.Text>().text = PlayerPrefs.GetString(DetailsNum.Substring(0, DetailsNum.Length-1));
    }

    private void SaveDetails()
    {
        PlayerPrefs.SetString(DetailsNum, Details.text);
    }

    private void loadDetials()
    {
        if (PlayerPrefs.HasKey(DetailsNum))
        {
            Details.text = PlayerPrefs.GetString(DetailsNum);
        }
    }

    public void back()
    {
        SaveDetails();
        SceneManager.LoadScene(4);
    }
}
