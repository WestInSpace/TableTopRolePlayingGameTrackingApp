using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.Windows;

public class Skills : MonoBehaviour
{
    //Used for getting info from other script
    GameObject Master;
    private MainMenu MasterScript;
    private string GameNum;
    private string Skill;
    //Used to load skills
    public GameObject Title;
    ArrayList StrSkills = new ArrayList{"StST", "Athletics"};
    ArrayList DexSkills = new ArrayList{"DeST", "Acrobatics", "Sleight of Hand", "Stealth"};
    ArrayList ConSkills = new ArrayList {"CoST"};
    ArrayList IntSkills = new ArrayList{"InST", "Arcana", "History", "Investigation", "Nature", "Religion"};
    ArrayList WisSkills = new ArrayList{"WiST", "Animal Handling", "Insight", "Medicine", "Perception", "Survival"};
    ArrayList ChaSkills = new ArrayList{"ChST", "Deception", "Intimidation", "Performance", "Persuasion"};
    ArrayList HoldSkills = new ArrayList();
    public GameObject SavingThrows;
    int distBetweenGameItems = 35;
    public GameObject Level;
    public GameObject Mod;
    //needed to save, load, and set skills
    private string SkillBeingSet;
    public GameObject ModSkillPop;
    public InputField ModSkillIn;
    private GameObject ButtonPressed;

    // Start is called before the first frame update
    void Start()
    {
        SavingThrows.SetActive(false);
        ModSkillPop.SetActive(false);
        Master = GameObject.FindGameObjectWithTag("Master");
        MasterScript = Master.GetComponent<MainMenu>();
        GameNum = MasterScript.GameNumber;
        Skill = MasterScript.SKILL;
        LoadStats();
    }

    //used on each SkillButton to make the ModSkillPop show up
    public void popUpModSkillPop()
    {
        if (ModSkillPop.activeSelf)
        {
            ModSkillPop.SetActive(false);
        }
        else
        {
            //Not the most efficiant way to move the popUp to the front but this is the
            //only way I could get it to work
            //************************************************************
            ModSkillPop.transform.SetParent(Level.transform);
            ModSkillPop.transform.SetParent(Level.transform.parent);
            //************************************************************
            if (UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject.name.Equals("Level"))
            {
                SkillBeingSet = GameNum + "." + Skill + "L";
            }
            else if (UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject.name.Equals("Mod"))
            {
                SkillBeingSet = GameNum + "." + Skill + "M";
            }
            else
            {
                ButtonPressed = UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject;
                SkillBeingSet = ButtonPressed.name;
            }
            ButtonPressed = UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject;
            ModSkillIn.text = "";
            ModSkillPop.SetActive(true);
        }
    }

    //Used on the enter button of the ModSkillPop
    public void SetSkill()
    {
        try
        {
            if (Int32.Parse(ModSkillIn.text) >= 0 && SkillBeingSet[SkillBeingSet.Length - 1] != 'L')
            {
                ModSkillIn.text = "+" + ModSkillIn.text;
            }
            PlayerPrefs.SetString(SkillBeingSet, ModSkillIn.text);
            //Display the text the user entered to the button they pressed
            ButtonPressed.transform.GetChild(1).transform.GetComponent<UnityEngine.UI.Text>().text = ModSkillIn.text;
            ModSkillPop.SetActive(false);
        }
        catch(Exception ex)
        {
            Debug.Log("Enter Integers only!");
            Debug.Log(ex);
        }
    }

    public void back()
    {
        SceneManager.LoadScene(2); //Load the MyCharacter scene
    }

    //Make sure that Skill and GameNum are properly set before calling
    public void LoadStats()
    {
        //Display the Mod and Level
        if (PlayerPrefs.HasKey(GameNum + "." + Skill + "L"))
        {
            Level.transform.GetChild(1).transform.GetComponent<UnityEngine.UI.Text>().text = PlayerPrefs.GetString(GameNum + "." + Skill + "L");
        }
        if (PlayerPrefs.HasKey(GameNum + "." + Skill + "M"))
        {
            Mod.transform.GetChild(1).transform.GetComponent<UnityEngine.UI.Text>().text = PlayerPrefs.GetString(GameNum + "." + Skill + "M");
        }

        //Disply all the skills
        if (Skill.Equals("STR"))
        {
            Title.transform.GetComponent<UnityEngine.UI.Text>().text = "Strength";
            HoldSkills = StrSkills;
        }
        else if (Skill.Equals("DEX"))
        {
            Title.transform.GetComponent<UnityEngine.UI.Text>().text = "Dextarity";
            HoldSkills = DexSkills;
        }
        else if (Skill.Equals("CON"))
        {
            Title.transform.GetComponent<UnityEngine.UI.Text>().text = "Constitution";
            HoldSkills = ConSkills;
        }
        else if (Skill.Equals("INT"))
        {
            Title.transform.GetComponent<UnityEngine.UI.Text>().text = "Intelligence";
            HoldSkills = IntSkills;
        }
        else if (Skill.Equals("WIS"))
        {
            Title.transform.GetComponent<UnityEngine.UI.Text>().text = "Wisdom";
            HoldSkills = WisSkills;
        }
        else
        {
            Title.transform.GetComponent<UnityEngine.UI.Text>().text = "Charisma";
            HoldSkills = ChaSkills;
        }

        //Display all the Skills for the selected stat
        for (int i=0; i<HoldSkills.Count; i++)
        {
            DisplayStats((string)HoldSkills[i], i);
        }
    }

    private void DisplayStats(string name, int NumItems)
    {
        string nameTag = name.Substring(0, 4);
        //clone the object
        GameObject clone = Instantiate(SavingThrows);
        //set the display text of the cloned game object
        if (NumItems > 0)
        {
            clone.transform.GetChild(0).GetComponent<UnityEngine.UI.Text>().text = name;
        }
        //set the name of the game object
        clone.name = GameNum + "." + nameTag;
        //Set the mod of the skill that is the cloned object
        if (PlayerPrefs.HasKey(GameNum + "." + nameTag))
        {
            clone.transform.GetChild(1).transform.GetComponent<UnityEngine.UI.Text>().text = PlayerPrefs.GetString(GameNum + "." + nameTag); ;
        }
        //Set the parent of the cloned game
        clone.transform.SetParent(SavingThrows.transform.parent);
        //Put the clone at its proper location
        float posX = SavingThrows.transform.position.x;
        float posY = SavingThrows.transform.position.y - distBetweenGameItems * NumItems;
        clone.transform.position = new Vector3(posX, posY);
        //make the clone visable
        clone.SetActive(true);
    }
}
