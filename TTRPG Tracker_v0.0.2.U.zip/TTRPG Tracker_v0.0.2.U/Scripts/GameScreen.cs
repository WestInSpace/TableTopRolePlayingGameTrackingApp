using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameScreen : MonoBehaviour
{
    public GameObject Title;

    //Used for getting info from other script
    GameObject Master;
    private MainMenu MasterScript;
    private string GameNum;

    void Start()
    {
        Master = GameObject.FindGameObjectWithTag("Master");
        MasterScript = Master.GetComponent<MainMenu>();
        GameNum = MasterScript.GameNumber; 
        UpdateTitle();
    }

    //Sets the title at the top of the screen to the name of the game that the user
    //entered
    private void UpdateTitle() //Make sure that GameNum is properly set before calling
    {
        Title.transform.GetComponent<UnityEngine.UI.Text>().text = PlayerPrefs.GetString("G" + GameNum);
    }

    public void BackToMain() {
        SceneManager.LoadScene(0);
    }

    public void MyCharacter()
    {
        SceneManager.LoadScene(2);
    }

    public void Locations()
    {

    }

    public void Notes()
    {

    }

    public void NPCs()
    {

    }
}
