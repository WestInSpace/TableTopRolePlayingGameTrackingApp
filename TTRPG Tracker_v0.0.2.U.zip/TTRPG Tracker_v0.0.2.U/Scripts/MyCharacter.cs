using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEditor.Experimental.GraphView;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MyCharacter : MonoBehaviour
{
    //needed to edit text
    public GameObject Name;
    public GameObject Clas;
    public GameObject Race;
    public GameObject Back;
    public GameObject STR;
    public GameObject DEX;
    public GameObject CON;
    public GameObject INT;
    public GameObject WIS;
    public GameObject CHA;
    public GameObject AC;
    public GameObject HP;
    public GameObject THP;
    //needed to edit values
    public GameObject EditValuePop;
    public InputField EditPopIn;
    private string EditedValue;
    private GameObject ButtonPressed;
    //Needed to Load details
    //Used for getting info from other script
    GameObject Master;
    private MainMenu MasterScript;
    private string GameNum;

    // Start is called before the first frame update
    void Start()
    {
        EditValuePop.SetActive(false);
        Master = GameObject.FindGameObjectWithTag("Master");
        MasterScript = Master.GetComponent<MainMenu>();
        GameNum = MasterScript.GameNumber;
        loadStats();
    }

    public void loadItemsScene()
    {
        GameObject buttonPressed = UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject;
        MasterScript.ItemType = buttonPressed.name;
        SceneManager.LoadScene(4);
    }

    public void PopUpEditValue()
    {
        if (EditValuePop.activeSelf)
        {
            EditValuePop.SetActive(false);
        }
        else
        {
            EditPopIn.text = "";
            ButtonPressed = UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject;
            EditedValue = GameNum + "." + ButtonPressed.name;
            EditValuePop.SetActive(true);
        }
    }

    public void EditValue()
    {
        PlayerPrefs.SetString(EditedValue, EditPopIn.text);
        //Display the text the user entered to the buton they pressed
        ButtonPressed.transform.GetChild(1).transform.GetComponent<UnityEngine.UI.Text>().text = EditPopIn.text;
        EditValuePop.SetActive(false);
    }

    public void loadStats()
    {
        Name.transform.GetChild(1).transform.GetComponent<UnityEngine.UI.Text>().text = PlayerPrefs.HasKey(GameNum + ".Name") ? PlayerPrefs.GetString(GameNum + ".Name") : "Name";
        Clas.transform.GetChild(1).transform.GetComponent<UnityEngine.UI.Text>().text = PlayerPrefs.HasKey(GameNum + ".Clas") ? PlayerPrefs.GetString(GameNum + ".Clas") : "Class";
        Race.transform.GetChild(1).transform.GetComponent<UnityEngine.UI.Text>().text = PlayerPrefs.HasKey(GameNum + ".Race") ? PlayerPrefs.GetString(GameNum + ".Race") : "Race";
        Back.transform.GetChild(1).transform.GetComponent<UnityEngine.UI.Text>().text = PlayerPrefs.HasKey(GameNum + ".Back") ? PlayerPrefs.GetString(GameNum + ".Back") : "Background";
        STR.transform.GetChild(3).transform.GetComponent<UnityEngine.UI.Text>().text = PlayerPrefs.HasKey(GameNum + ".STRL") ? PlayerPrefs.GetString(GameNum + ".STRL") : "0";
        STR.transform.GetChild(1).transform.GetComponent<UnityEngine.UI.Text>().text = PlayerPrefs.HasKey(GameNum + ".STRM") ? PlayerPrefs.GetString(GameNum + ".STRM") : "+0";
        DEX.transform.GetChild(3).transform.GetComponent<UnityEngine.UI.Text>().text = PlayerPrefs.HasKey(GameNum + ".DEXL") ? PlayerPrefs.GetString(GameNum + ".DEXL") : "0";
        DEX.transform.GetChild(1).transform.GetComponent<UnityEngine.UI.Text>().text = PlayerPrefs.HasKey(GameNum + ".DEXM") ? PlayerPrefs.GetString(GameNum + ".DEXM") : "+0";
        CON.transform.GetChild(3).transform.GetComponent<UnityEngine.UI.Text>().text = PlayerPrefs.HasKey(GameNum + ".CONL") ? PlayerPrefs.GetString(GameNum + ".CONL") : "0";
        CON.transform.GetChild(1).transform.GetComponent<UnityEngine.UI.Text>().text = PlayerPrefs.HasKey(GameNum + ".CONM") ? PlayerPrefs.GetString(GameNum + ".CONM") : "+0";
        INT.transform.GetChild(3).transform.GetComponent<UnityEngine.UI.Text>().text = PlayerPrefs.HasKey(GameNum + ".INTL") ? PlayerPrefs.GetString(GameNum + ".INTL") : "0";
        INT.transform.GetChild(1).transform.GetComponent<UnityEngine.UI.Text>().text = PlayerPrefs.HasKey(GameNum + ".INTM") ? PlayerPrefs.GetString(GameNum + ".INTM") : "+0";
        WIS.transform.GetChild(3).transform.GetComponent<UnityEngine.UI.Text>().text = PlayerPrefs.HasKey(GameNum + ".WISL") ? PlayerPrefs.GetString(GameNum + ".WISL") : "0";
        WIS.transform.GetChild(1).transform.GetComponent<UnityEngine.UI.Text>().text = PlayerPrefs.HasKey(GameNum + ".WISM") ? PlayerPrefs.GetString(GameNum + ".WISM") : "+0";
        CHA.transform.GetChild(3).transform.GetComponent<UnityEngine.UI.Text>().text = PlayerPrefs.HasKey(GameNum + ".CHAL") ? PlayerPrefs.GetString(GameNum + ".CHAL") : "0";
        CHA.transform.GetChild(1).transform.GetComponent<UnityEngine.UI.Text>().text = PlayerPrefs.HasKey(GameNum + ".CHAM") ? PlayerPrefs.GetString(GameNum + ".CHAM") : "+0";
        AC.transform.GetChild(1).transform.GetComponent<UnityEngine.UI.Text>().text = PlayerPrefs.HasKey(GameNum + ".AC") ? PlayerPrefs.GetString(GameNum + ".AC") : "0";
        HP.transform.GetChild(1).transform.GetComponent<UnityEngine.UI.Text>().text = PlayerPrefs.HasKey(GameNum + ".HP") ? PlayerPrefs.GetString(GameNum + ".HP") : "0";
        THP.transform.GetChild(1).transform.GetComponent<UnityEngine.UI.Text>().text = PlayerPrefs.HasKey(GameNum + ".THP") ? PlayerPrefs.GetString(GameNum + ".THP") : "0";
    }



    public void LoadSkillsScene()
    {
        MasterScript.SKILL = GetSkill();
        SceneManager.LoadScene(3); //Load the Skill edit scene
    }

    public void back()
    {
        SceneManager.LoadScene(1); //Load the GameScreen
    }

    private string GetSkill()
    {
        GameObject buttonPressed = UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject;
        string name = buttonPressed.name;
        return name;
    }

}
