using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.UIElements;

public class MainMenu : MonoBehaviour
{
    //variables
    //needed for taking the game name input
    public GameObject NewGamePop;
    public InputField GameNameInput;
    //needed to disply the game name
    public GameObject Game;
    int GameNum; //stores the number of the referanced game
    int distBetweenGameItems = 35;

    // Start is called before the first frame update
    void Start()
    {
        NewGamePop.active = false;
        Game.active = false;
        loadGames();
    }

    //PopUp/close the input to name and create a new game
    public void PopUpNewGame()
    {
        if (NewGamePop.active)
        {
            NewGamePop.active = false;
        }
        else
        {
            GameNameInput.text = "";
            NewGamePop.active = true;
        }
    }

    //create a new game, save the name to storage and disply it to the screen,
    //connected to the enter button
    public void CreateNewGame()
    {
        string name = GameNameInput.text;

        //save the game name
        //Update the number of games
        if (PlayerPrefs.HasKey("NumGames"))
        {
            PlayerPrefs.SetInt("NumGames", (PlayerPrefs.GetInt("NumGames")+1));
        }
        else
        {
            PlayerPrefs.SetInt("NumGames", 0);
        }
        //Save the name of the game to the proper serial number
        GameNum = PlayerPrefs.GetInt("NumGames");
        PlayerPrefs.SetString("G" + GameNum, name);

        CopyGame(name);

        NewGamePop.active = false;
    }
    
    //copy the game, set the text to the passed in name, and disply the game
    private void CopyGame(string name) //Make sure to properly set the Global GameNum variable before calling this method
    {
        //clone the object
        GameObject clone = Instantiate(Game);
        //set the display text of the cloned game object
        clone.transform.GetChild(0).GetComponent<UnityEngine.UI.Text>().text = name;
        //set the name of the game object
        clone.name = "G" + GameNum;
        //Set the parent of the cloned game
        clone.transform.SetParent(Game.transform.parent);
        //Put the clone at its proper location
        float posX = Game.transform.position.x;
        float posY = Game.transform.position.y - distBetweenGameItems * GameNum;
        clone.transform.position = new Vector3(posX, posY);
        //make the clone visable
        clone.active = true;
    }

    //get the name of each game from storage and display it to the screen
    private void loadGames()
    {
        if (PlayerPrefs.HasKey("NumGames")){
            for (int i=0; i<=PlayerPrefs.GetInt("NumGames"); i++)
            {
                GameNum = i;
                CopyGame(PlayerPrefs.GetString("G" + i));
            }
        }
    }
}
